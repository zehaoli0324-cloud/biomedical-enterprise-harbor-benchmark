# L5 next batch 010: V1.2 SOP calibration bundle

This author-side bundle contains three closed-loop policy tasks covering L5,
L5.1 and L5.3. Each task passed the V1.2 structural preflight, has an explicit
contract audit, a difficulty budget, held-out variant declarations, controls,
baselines and an independent verifier audit. Target-model records are retained
with their original contract-replay attribution; a contract replay pass is not
scientific difficulty evidence.

The package is not agent-facing and is not READY_FOR_HARBOR. Fixed-container
replay, practitioner review and held-out variant runs remain release blockers.
