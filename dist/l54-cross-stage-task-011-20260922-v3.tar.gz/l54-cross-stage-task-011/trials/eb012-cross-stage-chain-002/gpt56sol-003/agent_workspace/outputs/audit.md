# Cross-stage claim and provenance chain audit

## Selection and claim permission

The selected chain is **CHAIN-A**. It is the only eligible chain after applying every rule in the required order: recovery -> normalization -> route -> policy. Its robust CVaR is **0.820000**, which meets the 0.800000 threshold. Ineligible chains are excluded before ranking, so their higher scores do not affect selection.

CHAIN-A requests an **associational** claim. R-A, N-A, T-A, and P-A each permit operational, descriptive, and associational claims; therefore the minimum permission across the four artifacts is associational. The requested claim does not exceed that minimum. No causal claim is authorized.

## Upstream hash and inventory

For CHAIN-A, R-A has no upstream hash, N-A points to R-A's content hash `r-a`, T-A points to N-A's `n-a`, and P-A points to T-A's `t-a`. Every reported hash equals its artifact content hash. All four artifacts are active, schema-valid, and status `pass`.

The route reservation is `reserved` and its evidence quorum is **2**, meeting the required minimum quorum of 2. Normalization sensitivity is `stable`. P-A reports no future-outcome leakage and requires human review.

## Stop conditions and rejected chains

- CHAIN-B stops on T-B's reported hash mismatch (`wrong-t-b` versus `t-b`) and P-B's broken upstream link (`wrong-t-b` versus the preceding `t-b`), despite robust CVaR **0.950000**.
- CHAIN-C stops because T-C has an inventory reservation of `conflict`, not `reserved`, despite quorum 3 and robust CVaR **0.990000**.
- CHAIN-D stops because N-D sensitivity is `sensitive`, not stable, and its requested associational claim exceeds the chain minimum descriptive permission. Its robust CVaR is **0.910000**.

These stop conditions are applied before score ranking. All four policy artifacts otherwise have no future-outcome leakage and require human review, and all robust CVaR values meet the threshold.

## Why this is not experimental proof

This audit verifies supplied metadata, provenance links, integrity gates, routing evidence, policy controls, and a robust-CVaR eligibility threshold. It does not establish randomization, a control comparison, causal identification, measured outcomes, or replication. The selected result therefore supports only the permitted associational claim and remains subject to the required human review; it is not experimental proof.
