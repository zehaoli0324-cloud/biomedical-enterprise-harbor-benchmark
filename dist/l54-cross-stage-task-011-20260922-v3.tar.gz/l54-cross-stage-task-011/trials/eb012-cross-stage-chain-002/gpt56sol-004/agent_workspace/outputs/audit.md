# Cross-stage claim and provenance audit

## Decision

`CHAIN-A` is selected. It is the only eligible chain, with `robust_cvar` `0.820000`. The requested claim is associational, and the minimum permission across recovery, normalization, route, and policy is associational (level 3), so the request is within the permitted level. No causal permission is inferred.

## Chain review

| Chain | Robust CVaR | Minimum permission | Eligible | Stop condition |
|---|---:|---|---|---|
| CHAIN-A | 0.820000 | associational | yes | none |
| CHAIN-B | 0.950000 | associational | no | T-B reported hash mismatch; P-B upstream hash does not match T-B content hash |
| CHAIN-C | 0.990000 | associational | no | T-C reservation is `conflict`, not `reserved` |
| CHAIN-D | 0.910000 | descriptive | no | N-D sensitivity is not stable; requested associational claim exceeds descriptive permission |

The chain is evaluated in the required order: recovery -> normalization -> route -> policy. For CHAIN-A, the handoff is `R-A` (no upstream), `N-A` upstream `r-a`, `T-A` upstream `n-a`, and `P-A` upstream `t-a`; each equals the preceding content hash where applicable. All four artifacts are active, schema/status pass, and each reported hash equals its content hash.

The handoff claim-permission column records each artifact's highest listed permission. Chain eligibility uses the stricter minimum across all four artifacts; therefore CHAIN-D's recovery permission is associational but its chain minimum is descriptive because normalization, route, and policy are descriptive-only.

Upstream provenance is valid throughout CHAIN-C (`r-c` -> `n-c` -> `t-c` -> `p-c`) and CHAIN-D (`r-d` -> `n-d` -> `t-d` -> `p-d`). CHAIN-B is valid through `T-B`, but `P-B` reports upstream `wrong-t-b` instead of `T-B` content hash `t-b`, in addition to the `T-B` reported-hash mismatch.

## Inventory and human review

The route inventory is: CHAIN-A `reserved` with quorum 2, CHAIN-B `reserved` with quorum 2, CHAIN-C `conflict` with quorum 3, and CHAIN-D `reserved` with quorum 2. The selected reservation meets the required minimum quorum of 2. All four policies have `future_outcome_leakage` false and `human_review` true; human review is still required for the selected handoff. These are gating conditions: a conflict, insufficient quorum, leakage, or missing human review stops eligibility.

## Stop conditions

A chain is stopped and cannot be selected when any artifact is inactive, schema/status fails, a reported hash differs from content, an upstream hash differs from the preceding content hash, normalization sensitivity is not stable, route reservation/quorum fails, policy leaks future outcomes or lacks human review, robust CVaR is below `0.800000`, or the requested claim exceeds the minimum permission. Eligible chains would be ranked by descending robust CVaR and then ascending chain ID; in this case no tie-break is needed because only CHAIN-A remains eligible.

## Interpretation boundary

This is a deterministic provenance, routing, and claim-permission audit. It does not constitute experimental proof: the supplied records do not establish randomization, an intervention, a comparator, outcome measurement, or causal identification. Robust CVaR is a selection gate, not evidence that the requested association is causal or experimentally demonstrated. Human review remains required before operational use.
