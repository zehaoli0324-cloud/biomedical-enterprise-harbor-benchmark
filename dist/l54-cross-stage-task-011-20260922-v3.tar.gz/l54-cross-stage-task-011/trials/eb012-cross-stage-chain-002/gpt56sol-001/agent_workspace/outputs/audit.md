# Cross-stage claim and provenance audit

## Decision

`CHAIN-A` is the only eligible chain and is selected. Its policy `robust_cvar` is `0.820000`, which meets the `0.800000` threshold. The higher scores for CHAIN-B, CHAIN-C, and CHAIN-D do not matter because each chain fails at least one eligibility gate.

## Claim permission

The requested claim for CHAIN-A is **associational**. Every artifact in the chain permits operational, descriptive, and associational claims, so the minimum permission is associational and the request is within that limit. The audit does not upgrade a claim beyond the weakest artifact in a chain. CHAIN-D is also stopped on this rule: its normalization, route, and policy artifacts permit at most descriptive claims, while the request is associational.

## Upstream hash chain

For CHAIN-A, recovery starts with no upstream hash, then the links are `R-A (r-a) -> N-A (r-a) -> T-A (n-a) -> P-A (t-a)`. Each downstream `upstream_hash` equals the immediately preceding artifact's `content_hash`. The reported hash also equals the content hash for all four artifacts. CHAIN-B stops because `T-B` reports `wrong-t-b` instead of `t-b`, and `P-B` points to `wrong-t-b` rather than `T-B`'s content hash.

## Inventory and review

CHAIN-A's route reservation is `reserved` and has evidence quorum `2`, meeting the required minimum quorum of `2`. Its policy has no future-outcome leakage and requires human review. These are eligibility gates; the presence of human review means a reviewer must approve the policy decision before operational use.

## Stop conditions

The chain is stopped when any required gate fails, and stopped chains cannot win the robust-CVaR ranking. CHAIN-C stops because `T-C` has an inventory reservation of `conflict`, despite quorum `3`. CHAIN-D stops because `N-D` sensitivity is `sensitive` rather than stable and because its minimum claim permission is only descriptive. All artifacts are otherwise active with schema and status passing, and the policy leakage, human-review, and CVaR gates pass for these chains.

## Interpretation boundary

This is a deterministic provenance, inventory, policy, and claim-permission audit. It is not experimental proof: no randomized assignment, intervention, counterfactual identification, or causal design is supplied. A passing chain supports only the permitted associational claim for this audit, subject to human review; `robust_cvar` is a selection threshold, not evidence of causality or a measured experimental effect.
