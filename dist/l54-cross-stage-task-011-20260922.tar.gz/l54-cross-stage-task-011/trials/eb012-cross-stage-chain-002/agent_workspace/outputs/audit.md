# Cross-stage claim and provenance audit

## Selection and claim permission

The four artifacts in each chain were evaluated in the required order: recovery -> normalization -> route -> policy. CHAIN-A is selected because it is the only eligible chain. Its `robust_cvar` is `0.820000`, which clears the `0.800000` threshold. Selection is by highest robust CVaR among eligible chains, followed by ascending `chain_id`.

The requested claim for CHAIN-A is associational. Every artifact permits associational claims, so the minimum claim permission across recovery, normalization, route, and policy is associational. The requested claim does not exceed that minimum. No causal claim is authorized.

## Upstream hash and inventory checks

CHAIN-A has matching reported and content hashes at every stage, and its upstream links are exact: `N-A -> r-a`, `T-A -> n-a`, and `P-A -> t-a`. All four artifacts are active with schema and status checks passing. Normalization sensitivity is stable. The route inventory reservation is `reserved` and its evidence quorum is 2, meeting the required minimum quorum of 2.

CHAIN-B is stopped because `T-B` reports `wrong-t-b` instead of its content hash `t-b`; `P-B` also points to `wrong-t-b` rather than the preceding content hash `t-b`. CHAIN-C is stopped because `T-C` has an inventory reservation of `conflict`, despite having sufficient quorum. CHAIN-D is stopped because `N-D` sensitivity is `sensitive`, not stable, and its descriptive minimum permission cannot support the requested associational claim.

## Human review and stop conditions

The selected policy artifact `P-A` has no future-outcome leakage and requires human review. Human review remains a required gate before operational use; this audit does not replace that review.

A chain is ineligible and cannot be selected when any artifact is inactive, schema/status checks fail, a reported hash differs from its content hash, an upstream hash does not equal the prior content hash, normalization sensitivity is not stable, route reservation is not reserved, evidence quorum is below 2, policy leaks future outcomes, policy does not require human review, robust CVaR is below `0.800000`, or the requested claim exceeds the chain's minimum permission.

## Why this is not experimental proof

This is a deterministic provenance, integrity, routing, and policy-gating audit. It does not establish experimental or causal proof: there is no randomized assignment, control comparison, intervention validation, or outcome analysis in the supplied records. Robust CVaR is a screening threshold, and human review is a governance requirement; neither demonstrates that an intervention caused an outcome. The authorized result is therefore limited to the selected chain's associational claim permission.
