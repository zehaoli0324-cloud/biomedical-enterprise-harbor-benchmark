# L5.4 cross-stage task 011

Author-side package. Target trial verifier failure is retained as valid evidence; release remains blocked.
