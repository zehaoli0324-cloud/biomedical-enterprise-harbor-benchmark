# L4 tranche 005: provisional calibration bundle

Six complete synthetic enterprise evaluation tasks are included under `tasks/`.
This is an author-side bundle: `verifier.py`, `verifier_only/`, `tests/`,
`quality/`, `contracts/`, and `trials/` must never be exposed to a solving agent.
The agent-visible workspace consists only of each task's `instruction.md` and
`data/`, with a writable `outputs/` directory.

The earlier target-model trial failed the exact output contract; its records
remain unchanged. A later run against clarified instructions passed the local
verifier for all six tasks. Both trial results and their minimal artifacts are
included for review. This is provisional acceptance for packaging, not a
claim that the earlier failures passed and not READY_FOR_HARBOR.

The recorded model runs used `process_cwd_only`. Independent practitioner
review and fixed-container replay are still required before release.
`manifest.json` lists the task statuses and SHA-256 of every packaged file.
