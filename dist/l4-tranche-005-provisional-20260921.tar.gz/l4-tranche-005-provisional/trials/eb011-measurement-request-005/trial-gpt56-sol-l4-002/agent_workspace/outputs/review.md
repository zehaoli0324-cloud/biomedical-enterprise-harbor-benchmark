# Review

Deterministic planning decision: select M-02. Eligibility requires an uncertain, feasible measurement with gain at least the `min_value` in rules version `l4-v1`. Eligible options are ranked by `gain*(1-correlation)/cost`, descending, with measurement ID as the tie-break. M-02 ranks above M-01 after the correlation adjustment. M-03 is infeasible, and M-04 is already resolved (`current_uncertainty=false`).

Human review: not required for this run because the supplied evidence contains the required measurement fields and the binding invariant is present. Human review is still required before acting if the source data, interpretation of correlation, feasibility, or the ranking rule is disputed.

Stop conditions: stop and request human review if any required eligibility or ranking field is missing, if the binding invariant is missing or contradictory, if no feasible uncertain option meets `min_value`, or if the supplied evidence cannot support a deterministic ordering. Do not infer missing values.

This is a planning/review aid, not experimental proof. The correlation-adjusted values and selection do not establish causality, validity of a measurement, or experimental results.
