# Deterministic Measurement Review

The rule assigns eligible options the value `gain * (1 - correlation) / cost`. M-01 scores 0.12 and M-02 scores 0.585. M-03 is infeasible and M-04 does not have current uncertainty, so each receives -1. The maximum tuple is therefore `(0.585, M-02)`, and 0.585 is above the minimum value of 0.1. The decision is `M-02`.

Uncertainty remains because the calculation uses the supplied gain, correlation, cost, feasibility, and current-uncertainty fields as fixed inputs; it does not independently validate them or predict an observed result. This planning/review aid is not experimental proof.

No human review request or stop action is triggered because the deterministic rule returned a valid measurement selection rather than a hold, block, reject, escalation, or information request. A stop condition would apply only if the rule returned one of those outcomes.
