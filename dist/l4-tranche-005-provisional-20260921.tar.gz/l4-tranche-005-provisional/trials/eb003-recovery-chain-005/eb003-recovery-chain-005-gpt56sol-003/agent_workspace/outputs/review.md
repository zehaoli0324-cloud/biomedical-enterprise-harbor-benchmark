# Review

The deterministic rule selects `retry_clean`, the first branch with status `success`, no irreversible side effect, no failed invariants, and no disallowed causal permission request. `retry_fast` is rejected because its side effect is irreversible. `refresh_reference` is rejected because its failed-invariants list contains `reference`.

Uncertainty is limited to the supplied input fields and the stated rule. No human review or stop is triggered for this valid deterministic selection. Stop conditions apply if no branch remains eligible and the rule returns `escalate`, or if a hold, block, reject, or information request is returned; those outcomes require human review under the stated process.

This artifact is a planning/review aid and is not experimental proof.
