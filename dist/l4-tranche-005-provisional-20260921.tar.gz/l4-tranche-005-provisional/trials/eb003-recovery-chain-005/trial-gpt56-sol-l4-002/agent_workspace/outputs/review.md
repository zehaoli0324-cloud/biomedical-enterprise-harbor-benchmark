# Review

## Deterministic disposition

The deterministic decision is **stop pending human review** under rules version `l4-v1`.

`retry_clean` is the only branch whose supplied evidence shows success with no side effect and no failed invariant, so it is eligible for reviewed execution. `retry_fast` is successful but has an irreversible side effect and therefore requires explicit human authorization before execution. `refresh_reference` is successful but fails the binding `reference` invariant and must stop until a reviewer establishes that the invariant is satisfied or approves a documented remediation.

## Human review and stop conditions

Human review is required before any branch with an irreversible side effect is executed. Processing must stop when a binding invariant is missing or failed, as for `refresh_reference`. Review must also stop if the supplied evidence cannot establish the branch status, the side-effect reversibility, the invariant result, or the authority to proceed. No automatic override is inferred from a successful status.

## Provenance and uncertainty

All branch facts come from `data/case.json`; the rules version comes from `data/rules.json`. The evidence table preserves branch-level uncertainty and claim boundaries. No facts outside those files were used.

## Scope

This output is a planning/review aid, not experimental proof. It does not establish efficacy, causality, safety, or validity beyond the explicit operational and claim permissions in the supplied evidence.
