# Review

Decision: `request_information` under rules version `l4-v1`.

The supplied case includes a `high_failure` scenario and explicitly assigns the stage-two action `request_information` when that scenario applies. Because no follow-up information is supplied to resolve that branch, no candidate is selected for execution. The provisional feasible set is C-2, C-6, C-7, and C-8. It has four candidates, total cost 7.5 against the budget of 10.0, includes required groups A, B, and C, and violates no incompatibility pair. It remains provisional only.

Human review is required before any batch is authorized. Review should confirm which scenario governs the next batch, provide the information requested by the high-failure branch, and re-check candidate scope, group coverage, budget, batch size, and incompatibilities.

Stop conditions:

- Stop if the high-failure information is not supplied or the governing scenario remains ambiguous.
- Stop if any candidate identifier or source provenance cannot be reconciled to the supplied case.
- Stop if batch size, budget, required groups, or incompatibility constraints cannot all be satisfied after the information update.
- Stop and request human review if any binding invariant or required group is missing.

Uncertainty is preserved from each candidate record and is not treated as measured performance. This output is a planning/review aid, not experimental proof; it does not establish efficacy, safety, causality, or generalization.
