# Review

The deterministic rule selects `C-1,C-2,C-6,C-7`. These are the only four active candidates that form a legal batch: total cost is 9.0, required groups A, B, and C are present, and the C-2/C-4 incompatibility pair is avoided. The other exact size-four combinations are rejected for incompatibility or a missing required group. Candidate C-8 is pilot-scoped and therefore ineligible.

The selected batch has utility 2.28 in the nominal scenario and 1.792 in the high-failure scenario. The minimum utility is 1.792 and the mean utility is 2.036. Uncertainty values are included through the specified exploration weight of 0.5; they describe planning uncertainty in the inputs, not observed outcomes.

This is a planning aid and not experimental proof. No human review or stop is triggered because the rule returns a valid deterministic selection rather than a hold, block, reject, escalation, or information request. Human review remains appropriate if an input changes or if an operational stop condition is encountered; a stop or information request must then follow the stated rule rather than replace this selection with an unstated approval enum.
