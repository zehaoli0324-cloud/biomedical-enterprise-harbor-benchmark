# Cross-stage artifact handoff and claim boundary audit

The deterministic rule returns `block`. `normalization_report` passes because `scope_ok`, `schema_ok`, `hash_ok`, and `claim_boundary_ok` are all true. `route_portfolio` does not pass because `hash_ok` is false. Since every artifact must pass to use `proceed`, the final decision is `block`.

The failed hash check is the stated uncertainty for `route_portfolio`; no additional uncertainty was provided in the input. The failed artifact is a stop condition under the rule, so human review is appropriate before the handoff continues. This result is a planning/review aid and not experimental proof.
