# Review

Deterministic screening under rules version `l4-v1` identifies `hierarchical` as the only profile that satisfies all supplied checks: complete metadata, allowed unit level (`donor`), control range `0.08 <= 0.2`, retention `0.91 >= 0.8`, and preserved direction.

`global` is ineligible because retention is `0.42` and direction is not preserved. `site_local` cannot be accepted: metadata is incomplete and its `well` unit level is not in the allowed set. The incomplete metadata is a binding-invariant issue, so the overall decision is `human_review_required` and processing must stop pending review. `hierarchical` is recorded only as the provisional compliant candidate.

Human review is required to confirm the missing `site_local` metadata and determine whether that profile can ever satisfy the binding invariants. Stop conditions are: any unresolved `metadata_complete` requirement, any unit level outside `allowed_unit_levels`, any control range above `max_control_range`, retention below `min_retention`, or direction not preserved. No normalization authorization is implied until those conditions are resolved.

This output is a planning/review aid based only on the supplied offline evidence; it is not experimental proof.
