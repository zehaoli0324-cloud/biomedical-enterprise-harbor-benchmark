# hierarchical batch normalization under partial metadata

Use only the supplied offline evidence. Produce a deterministic decision, preserve provenance and uncertainty, and stop or request human review when a binding invariant is missing. This is a planning/review aid, not experimental proof.

Required outputs: `outputs/decision.json`, `outputs/evidence.tsv`, `outputs/review.md`, and `outputs/manifest.json`.

`decision.json` must contain `decision` and `rules_version` (and may include `details`). `evidence.tsv` must contain exactly one row for every profile entity in `data/case.json`, with columns `entity`, `outcome`, `decision`, `provenance`, `uncertainty`, and `claim_boundary`; use the profile name as `entity` and record its eligible status as `outcome`. `manifest.json` must contain `input_sha256` with the SHA-256 hashes of `case.json` and `rules.json`, plus `rules_version` and `deterministic: true`. `review.md` must explicitly state human review, stop conditions, and that this is not experimental proof.
