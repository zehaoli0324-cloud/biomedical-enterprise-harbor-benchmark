# Review

The deterministic rule selects `hierarchical`. It is eligible because metadata is complete, its control range (0.08) is within the maximum (0.2), retention (0.91) meets the minimum (0.8), direction is preserved, and `donor` is an allowed unit level. `global` is ineligible because retention and direction preservation fail. `site_local` is ineligible because metadata is incomplete and `well` is not an allowed unit level.

Uncertainty is limited to the supplied metadata and rule values; no unstated scoring or approval gate was applied. Because the result is a valid deterministic selection, no human review or stop action is requested. A stop condition would apply only if the rule returned `hold`, `block`, `reject`, `escalation`, or an information request. This output is a planning/review aid and not experimental proof.
