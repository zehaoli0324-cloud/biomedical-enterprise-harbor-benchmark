# EB014-002 interactive trial analysis

- `sequential-gpt56sol-007`: `RAW_PASS`, 10 observable model turns; counted_as_difficulty_failure=False.

The fixed sequence replay passed independently. A long trajectory target is exploratory and is not a minimum completion requirement. Provider, adapter, or network failures are infrastructure evidence, not model scientific failures.
