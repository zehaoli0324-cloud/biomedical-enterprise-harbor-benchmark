# L5.1 self-planned ambiguity task bundle

Author-side calibration bundle for eb010-closed-loop-ambiguity-004 v0.7.1. The package is not agent-facing and is not READY_FOR_HARBOR. Fixed-container replay, held-out variants and practitioner review remain release blockers.
