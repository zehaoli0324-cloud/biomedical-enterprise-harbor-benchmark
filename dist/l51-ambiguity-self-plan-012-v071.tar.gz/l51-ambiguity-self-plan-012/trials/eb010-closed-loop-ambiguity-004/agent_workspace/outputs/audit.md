# Policy Review Audit

This is a bounded planning decision, not experimental proof. The claim boundary is `planning_only_not_experimental_proof`.

## Workflow and controls

The selected workflow is `inventory -> interpret -> screen -> replay -> decide`. It supplies provenance, semantic resolution, eligibility screening, complete replay, and bounded decision capabilities at a total planning cost of 6.5, below the mission limit of 7.0. It uses no network (`network_used=false`) and stops at `eligible_record_selected`.

## Record review

- `P-ALPHA` has an unambiguous proceed cue, active scope, signal 0.62 above the 0.50 minimum, uncertainty 0.12 below the 0.20 maximum, two replays, a 0.04 utility range, and cost 4.5 within the 6.0 record budget. It is eligible and selected.
- `P-BETA` contains both proceed and review language. Under the ambiguity policy it is `ambiguous` and cannot be resolved by its higher utility; its uncertainty of 0.31 is also above the proceed maximum.
- `P-GAMMA` explicitly says to hold for a clearer signal, so it is `human_review`; its 0.45 signal also fails the threshold.
- `P-DELTA` relies on a later outcome estimate. Future-outcome leakage makes it `unresolved` and ineligible despite otherwise favorable numeric replay values.
- `P-ARCHIVE` is outside the required active scope, so it is `unresolved` and ineligible.

All records have two replays and utility ranges below the 0.20 stability limit, and all record costs are within the 6.0 budget; therefore stability and budget do not block `P-ALPHA`. The explicit review and ambiguity cases remain visible in the evidence, so `human_review_required` is true even though a clear eligible record is selected.
