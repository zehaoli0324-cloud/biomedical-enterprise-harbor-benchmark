# Evidence routing audit

The critical bottleneck is the pair of critical uncertainties: signal starts at 0.70 and must reach 0.25, while selectivity starts at 0.60 and must reach 0.25. `R-ASSAY` supplies reductions of 0.50 and 0.45 respectively, leaving residuals of 0.20 and 0.15. Its cost is 3.0, within the discovered maximum budget of 5.0, so this route crosses both critical thresholds. The non-critical reproducibility residual remains 0.45.

Only current requests with satisfied prerequisites and no post-decision outcome were eligible. `R-ASSAY` has no prerequisites. `R-REPL` was not eligible without `R-CHEM`; `R-INCOMPLETE` names the missing prerequisite `R-MISSING`; `R-ARCHIVE` is not current; and `R-POST` uses a future outcome and was excluded. Dependency closure was evaluated within the same candidate route.

Requests in a correlation group were not combined to manufacture reduction. In G1, `R-CHEM` (0.40 signal) dominates `R-CORR` (0.35 signal) for that uncertainty, but either alone leaves signal above its threshold and neither addresses selectivity. `R-ASSAY` is in G2 and independently covers both critical uncertainties. Routes that add requests without improving the maximum critical residual lose on cost; the selected route therefore has objective values maximum critical residual 0.20, cost 3.0, and lexical IDs [`R-ASSAY`].

No network was used (`network_used=false`, manifest network `off`), and no future outcome was consulted. The stop condition is `route_selected`; human review is not required. This is a bounded planning decision and **not experimental proof**.
