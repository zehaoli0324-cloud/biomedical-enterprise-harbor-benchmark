# L6 evidence-budget routing bundle

Author-side calibration bundle for eb013-evidence-budget-routing-001. The solving agent receives only instruction.md, data/ and writable outputs/. Release remains blocked pending fixed-container replay and practitioner review.
