# Evidence audit

The registered-cohort signal is supported after quality and pairing checks, but the evidence does not support a target-context, causal, efficacy, or universal claim. The final boundary is `registered_cohort_only`; transport and replication remain bounded holds, and confounding requires review.

## Measurement evidence

- **M-QC (quality):** Eight replicate effects were `[0.41, 0.43, 0.40, 0.44, 0.42, 0.41, 0.43, 0.42]`; coefficient of variation was `0.031` and blank rate `0.01`. This supports PASS for measurement quality.
- **M-PAIR (pairing):** Four complete pairwise deltas were `[0.41, 0.44, 0.39, 0.43]`, with `0` missing and `0` discordant pairs. Pairing is PASS.
- **M-PRIMARY (registered signal):** Effect `0.42` (95% CI `0.31-0.53`), `n=32`, standard error `0.055`, `p=0.0004`. The registered primary signal is SUPPORTED.
- **M-CONTEXT (transport comparison):** Registered effect `0.42` versus target effect `0.08`, context delta `-0.34`, target `n=24`, interaction `p=0.018`. The context shift means transport is HOLD.
- **M-REPL (independent replication):** Unit effects were `[0.39, 0.18, 0.21, 0.35, 0.23, 0.31]`; pooled effect `0.278`, `I^2=0.67`, range `0.18-0.39` across `6` units. Replication is heterogeneous and therefore HOLD.
- **M-NEG (negative control):** Control effect `0.12` (95% CI `0.05-0.19`), blank effect `0.03`, `z=2.7`. A negative-control signal activates confounding review.
- **M-ORTHO (orthogonal assay):** `4/5` markers were concordant (`0.8`), with local effect `0.11`; this confirms a local signal but not transport.
- **M-BRIDGE (bridge):** Source effect `0.42`, target effect `0.05`, transport ratio `0.12`, target 95% CI `0.01-0.09`; bridge failed to establish transport.
- **M-INFLUENCE (leave-one-out):** Influential unit `D1` had full effect `0.39` and leave-one-out effect `0.18`, a change of `-0.21`; `42%` of signal was attributed to that unit. This limits replication stability.
- **M-CONFOUND (adjustment):** Target unadjusted effect `0.08` fell to `0.02` after adjustment; covariate shift was `0.31`, with stratum effects `[0.01, 0.02, 0.03]`. Confounding was localized but remains REVIEW_REQUIRED.
- **M-ROBUST (sensitivity):** Registered effects across the grid were `[0.37, 0.40, 0.42, 0.44]`, sign-consistent; target effects were `[0.01, 0.02, 0.04, 0.05]` and not transport-consistent. Robustness is REGISTERED_ONLY.

The replicate vector, uncertainty intervals, context delta, heterogeneity, negative control, transport ratio, influence change, adjusted strata, and sensitivity grid are all retained above. These measurements support only the registered-cohort primary signal and the stated limitations.

## Decision boundary

Quality and pairing PASS; primary registered signal SUPPORTED; context and replication HOLD; confounding REVIEW_REQUIRED; robustness REGISTERED_ONLY. Human review is required. No target-context efficacy or causal claim is authorized.
